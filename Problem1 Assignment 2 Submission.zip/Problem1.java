//Name: Thumar Grishma Maheshbhai
//Student: 922950012
//Assignment 2: Calculating Area and Perimeter

public class Problem1 {
        /**
         * In this program, we are going to calculate the area and perimeter of a rectangle.
         * The formulas are:
         * area = length * width
         * perimeter = 2 * (length + width)
         * There are comments below to guide you to write the program step-by-step. Write your code immediately below
         * each comment
         */
        public static void main(String[] args) {

            // Length and width are two properties of a rectangle. Their values need to be stored so that we can
            // calculate the area and the perimeter. Declare two variables with meaningful names to store the values.
            // Be mindful of the datatype you use.
            double length, width;



            // We also need variables to store the area and perimeter once the values are computed.
            // Declare two variables with meaningful names to store the area and the perimeter once they are calculated.
            double area, perimeter;


            // Let's first compute the area. Use the formula for area to write the expression that will calculate the area.
            // Once the expression is evaluated, it needs to be stored in a variable otherwise we can't use it later on.
            // Hint: you need to assign the computed value to the variable that you created above.
            length = 23.5;
            width = 5.5;
            area = length * width;


            // Now, let's do something similar to compute the perimeter. Use the formula to calculate the perimeter of a
            // rectangle. Remember to assign the computed value to the appropriate variable.
            perimeter = 2 * (length + width);



            // You have so far stored the correctly computed values in two variables.
            // Now, one by one print out the values on your console. You will write at least two print statements, one
            // to print the area and one to print the perimeter.
            // Tip: You can use the + operator to add text, something like: ("The area is: " + <variable_name_goes_here>)
            System.out.println("The area of length " + length + " m and width " + width + " m is: " + area + " m2.");
            System.out.println("The perimeter of length " + length + " m and width " + width + " m is: " + perimeter + " m");


        }
    }
